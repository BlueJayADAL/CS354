#!/bin/bash

# Ensure the script is run as jj
if [ "$(whoami)" != "jj" ]; then
    echo "This script must be run as user jj!"
    exit 1
fi

echo -e "\n***************************************************************"
echo "Updating system packages..."
echo "***************************************************************"
sudo apt update -y

# Check if hadoop user exists and remove it if necessary
if id "hadoop" &>/dev/null; then
    echo -e "\n***************************************************************"
    echo "User 'hadoop' already exists. Deleting the user and its home directory..."
    echo "***************************************************************"
    sudo systemctl stop hadoop-* 2>/dev/null  # Stop Hadoop services if running
    sudo pkill -u hadoop                      # Kill all processes by hadoop
    sudo userdel -r hadoop                     # Delete user and home directory
    sudo rm -rf /home/hadoop                   # Ensure full cleanup
fi

# Create new hadoop user
echo -e "\n***************************************************************"
echo "Creating user 'hadoop'..."
echo "***************************************************************"
sudo adduser --disabled-password --gecos "" hadoop
sudo mkdir -p /home/hadoop
sudo chown hadoop:hadoop /home/hadoop
sudo chmod 755 /home/hadoop  # Ensure hadoop can access its home directory

# Add hadoop user to sudo group
echo -e "\n***************************************************************"
echo "Adding 'hadoop' user to sudo group..."
echo "***************************************************************"
sudo usermod -aG sudo hadoop

# Set correct permissions for config files
sudo chmod 644 configs/*
sudo chown jj:jj configs/*

echo -e "\n***************************************************************"
echo "Installing Java 8 and OpenSSH..."
echo "***************************************************************"
sudo apt install openjdk-8-jdk openssh-server openssh-client -y

# Get Java home path
JAVA_HOME_PATH=$(readlink -f /usr/bin/java | sed "s:/bin/java::")
echo "Detected JAVA_HOME: $JAVA_HOME_PATH"

# Add environment variables from env.txt to both users
echo -e "\n***************************************************************"
echo "Adding environment variables from env.txt to ~/.bashrc..."
echo "***************************************************************"
if [ -f env.txt ]; then
    cat env.txt >> ~/.bashrc
    echo "export JAVA_HOME=$JAVA_HOME_PATH" >> ~/.bashrc
    source ~/.bashrc
else
    echo "ERROR: env.txt file not found!"
    exit 1
fi

# Setup SSH for hadoop user
echo -e "\n***************************************************************"
echo "Setting up passwordless SSH for Hadoop user..."
echo "***************************************************************"
sudo -u hadoop bash <<EOF
    mkdir -p /home/hadoop/.ssh
    ssh-keygen -t rsa -P '' -f /home/hadoop/.ssh/id_rsa
    cat /home/hadoop/.ssh/id_rsa.pub >> /home/hadoop/.ssh/authorized_keys
    chmod 600 /home/hadoop/.ssh/authorized_keys
EOF

# Download and extract Hadoop
echo -e "\n***************************************************************"
echo "Downloading and extracting Hadoop..."
echo "***************************************************************"
sudo -u hadoop bash <<EOF
    wget https://dlcdn.apache.org/hadoop/common/hadoop-3.4.1/hadoop-3.4.1.tar.gz -P /home/hadoop
    tar xzf /home/hadoop/hadoop-3.4.1.tar.gz -C /home/hadoop
    rm /home/hadoop/hadoop-3.4.1.tar.gz  # Clean up tar file
EOF

# Download Hadoop Streaming JAR
echo -e "\n***************************************************************"
echo "Downloading Hadoop Streaming JAR file..."
echo "***************************************************************"
sudo -u hadoop bash <<EOF
    wget https://repo1.maven.org/maven2/org/apache/hadoop/hadoop-streaming/3.4.1/hadoop-streaming-3.4.1.jar -P /home/hadoop/hadoop-3.4.1
EOF

# Append environment variables to hadoop user's ~/.bashrc
echo -e "\n***************************************************************"
echo "Applying environment variables for hadoop user..."
echo "***************************************************************"
sudo -u hadoop bash <<EOF
    if [ -f /home/jj/env.txt ]; then
        cat /home/jj/env.txt >> /home/hadoop/.bashrc
        echo "export JAVA_HOME=$JAVA_HOME_PATH" >> /home/hadoop/.bashrc
        source /home/hadoop/.bashrc
    else
        echo "ERROR: env.txt file not found in /home/jj!"
        exit 1
    fi
EOF

# Copy Hadoop configuration files
echo -e "\n***************************************************************"
echo "Configuring Hadoop..."
echo "***************************************************************"
sudo -u hadoop bash <<EOF
    cp /home/jj/configs/hadoop-env.sh /home/hadoop/hadoop-3.4.1/etc/hadoop/hadoop-env.sh
    cp /home/jj/configs/core-site.xml /home/hadoop/hadoop-3.4.1/etc/hadoop/core-site.xml
    cp /home/jj/configs/hdfs-site.xml /home/hadoop/hadoop-3.4.1/etc/hadoop/hdfs-site.xml
    cp /home/jj/configs/mapred-site.xml /home/hadoop/hadoop-3.4.1/etc/hadoop/mapred-site.xml
    cp /home/jj/configs/yarn-site.xml /home/hadoop/hadoop-3.4.1/etc/hadoop/yarn-site.xml
EOF

# Fix JAVA_HOME in hadoop-env.sh
sudo -u hadoop bash <<EOF
    sed -i "s|export JAVA_HOME=.*|export JAVA_HOME=$JAVA_HOME_PATH|" /home/hadoop/hadoop-3.4.1/etc/hadoop/hadoop-env.sh
EOF

# Format the HDFS
echo -e "\n***************************************************************"
echo "Formatting HDFS..."
echo "***************************************************************"
sudo -u hadoop bash <<EOF
    /home/hadoop/hadoop-3.4.1/bin/hdfs namenode -format
EOF

# Start Hadoop
echo -e "\n***************************************************************"
echo "Starting Hadoop..."
echo "***************************************************************"
sudo -u hadoop bash <<EOF
    /home/hadoop/hadoop-3.4.1/sbin/start-dfs.sh
    /home/hadoop/hadoop-3.4.1/sbin/start-yarn.sh
EOF

# Modify HDFS permissions
echo -e "\n***************************************************************"
echo "Modifying HDFS permissions..."
echo "***************************************************************"
sudo -u hadoop bash <<EOF
    /home/hadoop/hadoop-3.4.1/bin/hdfs dfs -chmod 777 /
EOF

echo -e "\n*********************************************"
echo "Hadoop installation complete!"
echo "Hadoop Namenode: http://localhost:9870"
echo "Hadoop Datanode: http://localhost:9864"
echo "YARN Resource Manager: http://localhost:8088"
echo "*********************************************"
