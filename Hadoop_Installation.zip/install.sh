#!/bin/bash

# Make sure the script runs as the original user jj
if [ "$(whoami)" != "jj" ]; then
    echo "This script must be run as user jj!"
    exit 1
fi

echo -e "\n***************************************************************"
echo "Updating system packages..."
echo "***************************************************************"
sudo apt update -y

# Create hadoop user if it doesn't exist
if ! id "hadoop" &>/dev/null; then
    echo -e "\n***************************************************************"
    echo "Creating user 'hadoop'..."
    echo "***************************************************************"
    sudo adduser --disabled-password --gecos "" hadoop
else
    echo "'hadoop' user already exists, skipping user creation."
fi

echo -e "\n***************************************************************"
echo "Installing Java 8 and OpenSSH..."
echo "***************************************************************"
sudo apt install openjdk-8-jdk openssh-server openssh-client -y

# Setup SSH for hadoop user
echo -e "\n***************************************************************"
echo "Setting up passwordless SSH for Hadoop user..."
echo "***************************************************************"
sudo -u hadoop bash <<EOF
    ssh-keygen -t rsa -P '' -f /home/hadoop/.ssh/id_rsa
    cat /home/hadoop/.ssh/id_rsa.pub >> /home/hadoop/.ssh/authorized_keys
    chmod 600 /home/hadoop/.ssh/authorized_keys
EOF

# Download and extract Hadoop
echo -e "\n***************************************************************"
echo "Downloading and extracting Hadoop..."
echo "***************************************************************"
sudo -u hadoop bash <<EOF
    wget https://dlcdn.apache.org/hadoop/common/hadoop-3.4.1/hadoop-3.4.1.tar.gz -P /home/hadoop
    tar xzf /home/hadoop/hadoop-3.4.1.tar.gz -C /home/hadoop
    echo "export HADOOP_HOME=/home/hadoop/hadoop-3.4.1" >> /home/hadoop/.bashrc
    echo "export PATH=\$HADOOP_HOME/bin:\$HADOOP_HOME/sbin:\$PATH" >> /home/hadoop/.bashrc
    source /home/hadoop/.bashrc
EOF

# Copy configuration files
echo -e "\n***************************************************************"
echo "Configuring Hadoop..."
echo "***************************************************************"
sudo -u hadoop bash <<EOF
    cp -f configs/hadoop-env.sh /home/hadoop/hadoop-3.4.1/etc/hadoop/hadoop-env.sh
    cp -f configs/core-site.xml /home/hadoop/hadoop-3.4.1/etc/hadoop/core-site.xml
    cp -f configs/hdfs-site.xml /home/hadoop/hadoop-3.4.1/etc/hadoop/hdfs-site.xml
    cp -f configs/mapred-site.xml /home/hadoop/hadoop-3.4.1/etc/hadoop/mapred-site.xml
    cp -f configs/yarn-site.xml /home/hadoop/hadoop-3.4.1/etc/hadoop/yarn-site.xml
EOF

# Format the HDFS
echo -e "\n***************************************************************"
echo "Formatting HDFS..."
echo "***************************************************************"
sudo -u hadoop bash <<EOF
    /home/hadoop/hadoop-3.4.1/bin/hdfs namenode -format
EOF

# Start Hadoop
echo -e "\n***************************************************************"
echo "Starting Hadoop..."
echo "***************************************************************"
sudo -u hadoop bash <<EOF
    /home/hadoop/hadoop-3.4.1/sbin/start-dfs.sh
    /home/hadoop/hadoop-3.4.1/sbin/start-yarn.sh
EOF

# Modify HDFS permissions
echo -e "\n***************************************************************"
echo "Modifying HDFS permissions..."
echo "***************************************************************"
sudo -u hadoop bash <<EOF
    /home/hadoop/hadoop-3.4.1/bin/hdfs dfs -chmod 777 /
EOF

echo -e "\n*********************************************"
echo "Hadoop installation complete!"
echo "Hadoop Namenode: http://localhost:9870"
echo "Hadoop Datanode: http://localhost:9864"
echo "YARN Resource Manager: http://localhost:8088"
echo "*********************************************"
