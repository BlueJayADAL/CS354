#!/bin/bash

##########################################################
# IMPOARTANT:
# Before running the following commands, make sure
# you have swticthed to the jj account.
##########################################################
# Update aptitude (app store)
sudo apt update

# Create a new account hadoop
echo -e "\n***************************************************************"
echo "We are creating a new account hadoop"
echo "And you will be asked to enter a password twice (remember it)"
echo "You won't see the password as you type but it is being recorded"
echo "For full name and other information, you can just press Enter"
echo "***************************************************************"
sudo adduser hadoop

# Then install Java 8
echo -e "\n***************************************************************"
echo "Installing Java 8 and OpenSSH"
echo "***************************************************************"
sudo apt install openjdk-8-jdk -y

# Then install OpenSSH
sudo apt install openssh-server openssh-client -y

# Add the following lines to the end of the file ~/.bashrc
echo -e "\n***************************************************************"
echo "Adding environment variables to ~/.bashrc"
echo "***************************************************************"
cat env.txt >> ~/.bashrc
source ~/.bashrc

#================================================
echo -e "\n***************************************************************"
echo "Cleaning up the apt cache"
echo "***************************************************************"
# Clean up the apt cache 
sudo apt clean
sudo rm -rf /var/lib/apt/lists/*


#================================================
echo -e "\n*********************************************"
echo "hadoop user account successfully created"
echo "Software and environment setup completed"
echo "Now, switch to hadoop account and run step 2"
echo "Use the following command to switch to hadoop:"
echo "        sudo su - hadoop"
echo "*********************************************"