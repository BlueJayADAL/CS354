#!/bin/bash

##########################################################
# IMPOARTANT:
# Before running the following commands, make sure
# you have swticthed to the jj account.
##########################################################
# Create a new account hadoop
sudo adduser hadoop

# Then install Java 8
sudo apt install openjdk-8-jdk -y

# Then install OpenSSH
sudo apt install openssh-server openssh-client -y

# Add the following lines to the end of the file ~/.bashrc
cat env.txt >> ~/.bashrc
source ~/.bashrc

#================================================
echo "Cleaning up ..."

# Clean up the apt cache 
sudo apt clean
sudo rm -rf /var/lib/apt/lists/*


#================================================
echo "*********************************************"
echo "hadoop user account created"
echo "Software and environment setup completed"
echo "Now, switch to hadoop account and run step 2"
echo "*********************************************"


