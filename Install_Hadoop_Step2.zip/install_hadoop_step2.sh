#!/bin/bash

##########################################################
# IMPOARTANT:
# Before running the following commands, make sure
# you have swticthed to the hadoop account.
#        sudo su - hadoop
##########################################################

# Generate the public and private key pairs for passwordless SSH
echo "Generating public and private key pairs for passwordless SSH ..."
ssh-keygen -t rsa -P '' -f /home/hadoop/.ssh/id_rsa
cat /home/hadoop/.ssh/id_rsa.pub >> /home/hadoop.ssh/authorized_keys
chmod 0600 /home/hadoop/.ssh/authorized_keys

# Download Hadoop to hadoop home directory
echo "Downloading Hadoop (this may take a little while) ..."
wget https://dlcdn.apache.org/hadoop/common/hadoop-3.4.1/hadoop-3.4.1.tar.gz -P /home/hadoop
tar xzf /home/hadoop/hadoop-3.4.1.tar.gz -C /home/hadoop

# Add the following lines to the end of the file ~/.bashrc
echo "Setting up environment variables ..."
cat env.txt >> ~/.bashrc

# Reload the .bashrc file
source ~/.bashrc

# Overwrite the original config files with the provided ones
echo "Configuring Hadoop ..."
cp -f configs/hadoop-env.sh $HADOOP_HOME/etc/hadoop/hadoop-env.sh
cp -f configs/core-site.xml $HADOOP_HOME/etc/hadoop/core-site.xml
cp -f configs/hdfs-site.xml $HADOOP_HOME/etc/hadoop/hdfs-site.xml
cp -f configs/mapred-site.xml $HADOOP_HOME/etc/hadoop/mapred-site.xml
cp -f configs/yarn-site.xml $HADOOP_HOME/etc/hadoop/yarn-site.xml

# Format the HDFS
echo "Formatting HDFS ..."
hdfs namenode -format

# Make HDFS permission changes so other accounts like jj can access it
hdfs dfs -chmod 777 /

# Start Hadoop
echo "Starting Hadoop ..."
start-dfs.sh
start-yarn.sh


#================================================
echo "*********************************************"
echo "Hadoop installation is complete."
echo "Hadoop Namenode: http://localhost:9870"
echo "Hadoop Datanode: http://localhost:9864"
echo "YARN Resource Manager: http://localhost:8088"
echo "*********************************************"


