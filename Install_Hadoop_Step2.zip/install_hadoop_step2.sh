#!/bin/bash

##########################################################
# IMPOARTANT:
# Before running the following commands, make sure
# you have swticthed to the hadoop account.
#        sudo su - hadoop
##########################################################

# Generate the public and private key pairs for passwordless SSH
echo -e "\n***************************************************************"
echo "Hadoop needs public and private key pairs for passwordless SSH"
echo "Generating public and private key pairs for passwordless SSH ..."
echo "***************************************************************"
ssh-keygen -t rsa -P '' -f /home/hadoop/.ssh/id_rsa
cat /home/hadoop/.ssh/id_rsa.pub >> /home/hadoop/.ssh/authorized_keys
chmod 0600 /home/hadoop/.ssh/authorized_keys

# Download Hadoop to hadoop home directory
echo -e "\n***************************************************************"
echo "Downloading Hadoop (this may take a little while) ..."
echo "And extracting the tarball ..."
echo "***************************************************************"
wget https://dlcdn.apache.org/hadoop/common/hadoop-3.4.1/hadoop-3.4.1.tar.gz -P /home/hadoop
tar xzf /home/hadoop/hadoop-3.4.1.tar.gz -C /home/hadoop

# Add the following lines to the end of the file ~/.bashrc
echo -e "\n***************************************************************"
echo "Adding environment variables to ~/.bashrc"
echo "***************************************************************"
cat env.txt >> ~/.bashrc

# Reload the .bashrc file
source ~/.bashrc

# Overwrite the original config files with the provided ones
echo -e "\n***************************************************************"
echo "Configuring Hadoop ..."
echo "***************************************************************"
cp -f configs/hadoop-env.sh $HADOOP_HOME/etc/hadoop/hadoop-env.sh
cp -f configs/core-site.xml $HADOOP_HOME/etc/hadoop/core-site.xml
cp -f configs/hdfs-site.xml $HADOOP_HOME/etc/hadoop/hdfs-site.xml
cp -f configs/mapred-site.xml $HADOOP_HOME/etc/hadoop/mapred-site.xml
cp -f configs/yarn-site.xml $HADOOP_HOME/etc/hadoop/yarn-site.xml

# Format the HDFS
echo -e "\n***************************************************************"
echo "Formatting HDFS ..."
echo "***************************************************************"
hdfs namenode -format


# Start Hadoop
echo -e "\n***************************************************************"
echo "Starting Hadoop ..."
echo "Hadoop is not automatically started when the system boots"
echo "You need to start it manually every time you restart the system"
echo "***************************************************************"
start-dfs.sh
start-yarn.sh

# Make HDFS permission changes so other accounts like jj can access it
echo -e "\n***************************************************************"
echo "Changing HDFS permissions to allow all users ..."
echo "***************************************************************"
hdfs dfs -chmod 777 /

#================================================
echo -e "\n*********************************************"
echo "Hadoop installation is complete."
echo "Hadoop Namenode: http://localhost:9870"
echo "Hadoop Datanode: http://localhost:9864"
echo "YARN Resource Manager: http://localhost:8088"
echo "*********************************************"


